<?php
	return array(
		'modules'=>'page',
		'templates/admin'=>'page',
		'templates/public'=>'page'
	);
?>
