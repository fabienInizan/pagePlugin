<h2><?php echo stripslashes($page->getTitle()); ?></h2>

<?php echo stripslashes($page->getContent()); ?>
