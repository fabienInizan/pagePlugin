<?php
	return array(
		'id'=>'page',
		'title'=>'Pages',
		'description'=>'Ajoutez, supprimez et éditez les pages de votre site.',
		'version'=>'1.0',
		'date'=>'2012-09-10'
	);
?>
