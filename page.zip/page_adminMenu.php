<?php
	return array(	'title'=>'Pages',
			'description'=>'Éditez les pages d\'information du site',
			'link'=>'?module=page&action=index'
	);
?>
